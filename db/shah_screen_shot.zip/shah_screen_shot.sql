-- phpMyAdmin SQL Dump
-- version 4.2.6deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 09, 2014 at 11:07 PM
-- Server version: 5.5.40-0ubuntu1
-- PHP Version: 5.5.12-2ubuntu4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shah_screen_shot`
--

-- --------------------------------------------------------

--
-- Table structure for table `alarm`
--

CREATE TABLE IF NOT EXISTS `alarm` (
`id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end` date NOT NULL,
  `recurring` smallint(1) NOT NULL COMMENT '0: none, 1: daily, 2: weekly'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=246 ;

--
-- Dumping data for table `alarm`
--

INSERT INTO `alarm` (`id`, `site_id`, `start`, `end`, `recurring`) VALUES
(203, 63, '2014-12-07 20:55:00', '0000-00-00', 0),
(196, 59, '2014-12-07 20:28:00', '0000-00-00', 0),
(205, 65, '2014-12-08 01:30:00', '2014-12-12', 1),
(220, 67, '2014-12-09 03:20:00', '0000-00-00', 0),
(231, 58, '2014-12-08 20:45:00', '2014-12-08', 0),
(204, 64, '2014-12-07 21:10:00', '0000-00-00', 0),
(194, 57, '2014-12-07 20:24:00', '0000-00-00', 0),
(230, 58, '2014-12-07 20:23:00', '0000-00-00', 0),
(219, 66, '2014-12-08 23:25:00', '0000-00-00', 0),
(193, 56, '2014-12-07 20:20:00', '0000-00-00', 0),
(192, 55, '2014-12-08 09:20:00', '2014-12-08', 0),
(188, 49, '2014-12-08 05:10:00', '2014-12-07', 0),
(202, 62, '2014-12-07 20:54:00', '2014-12-07', 0),
(185, 47, '2014-12-07 17:00:00', '2014-12-08', 1),
(183, 46, '2014-12-07 17:00:00', '2014-12-08', 0),
(218, 61, '2014-12-07 20:55:00', '0000-00-00', 0),
(181, 54, '2014-12-07 16:00:00', '2014-12-10', 1),
(180, 54, '2014-12-07 15:50:00', '2014-12-07', 0),
(179, 54, '2014-12-07 15:40:00', '2014-12-07', 0),
(191, 51, '2014-12-07 17:50:00', '2014-12-07', 1),
(182, 46, '2014-12-07 15:50:00', '2014-12-10', 0),
(184, 47, '2014-12-07 15:40:00', '2014-12-07', 2),
(187, 49, '2014-12-07 15:21:00', '2014-12-07', 0),
(186, 49, '2014-12-07 15:40:00', '2014-12-09', 1),
(213, 60, '2014-12-08 17:20:00', '2014-12-08', 0),
(217, 61, '2014-12-08 17:20:00', '2014-12-09', 1),
(221, 68, '2014-12-09 17:35:00', '0000-00-00', 0),
(222, 69, '2014-12-09 17:45:00', '0000-00-00', 0),
(223, 70, '2014-12-09 17:43:00', '0000-00-00', 0),
(241, 71, '2014-12-09 17:45:00', '0000-00-00', 0),
(225, 72, '2014-12-09 17:50:00', '0000-00-00', 0),
(226, 73, '2014-12-09 17:55:00', '0000-00-00', 0),
(227, 74, '2014-12-09 18:00:00', '0000-00-00', 0),
(242, 71, '2014-12-09 20:30:00', '2014-12-09', 1),
(237, 76, '2014-12-09 18:40:00', '2014-12-09', 0),
(232, 77, '2014-12-09 18:40:00', '2014-12-09', 0),
(239, 75, '2014-12-09 19:00:00', '2014-12-09', 0),
(238, 76, '2014-12-09 18:55:00', '2014-12-09', 0),
(243, 78, '2014-12-09 21:35:00', '2014-12-09', 1),
(244, 79, '2014-12-09 21:40:00', '2014-12-09', 2),
(245, 80, '2014-12-09 21:40:00', '2014-12-09', 0);

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE IF NOT EXISTS `calendar` (
`id` int(16) NOT NULL,
  `user_id` int(5) NOT NULL,
  `date` date NOT NULL,
  `event` varchar(32) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `calendar`
--

INSERT INTO `calendar` (`id`, `user_id`, `date`, `event`) VALUES
(1, 1, '2013-05-11', 'Imran Khan became Captain of KPK'),
(2, 1, '2013-05-04', 'Heloo'),
(3, 1, '2013-05-03', 'Hello'),
(4, 1, '2013-05-08', 'Rally in the evening'),
(5, 1, '2013-05-29', 'IT Expo in Deans'),
(6, 1, '2013-05-30', 'IT Expo Deans'),
(7, 1, '2013-05-31', 'IT Expo Deans'),
(8, 1, '2013-05-17', 'To Islamabad by moterway'),
(9, 1, '2013-05-28', '456456'),
(10, 1, '2013-05-06', 'Past events are called History'),
(11, 1, '2013-05-09', 'Rally in the evening\r\n'),
(12, 1, '2013-08-07', 'Testing\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `ci_query`
--

CREATE TABLE IF NOT EXISTS `ci_query` (
`id` int(11) NOT NULL,
  `query_string` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
`id` mediumint(8) unsigned NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'Manager', 'System Manager'),
(3, 'members', 'General User Group ');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE IF NOT EXISTS `login_attempts` (
`id` int(11) NOT NULL,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `privileges`
--

CREATE TABLE IF NOT EXISTS `privileges` (
`id` int(10) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `icon` varchar(255) NOT NULL,
  `controller` varchar(50) DEFAULT NULL,
  `view` varchar(50) DEFAULT '',
  `url` varchar(50) DEFAULT NULL,
  `order` int(2) unsigned DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT '0',
  `parent_id` int(10) unsigned DEFAULT NULL,
  `active` int(1) unsigned DEFAULT '1'
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `privileges`
--

INSERT INTO `privileges` (`id`, `title`, `icon`, `controller`, `view`, `url`, `order`, `group_id`, `parent_id`, `active`) VALUES
(1, 'Dashboard', 'icon icon-home', 'dashboard', '', NULL, 1, 0, 0, 0),
(44, 'Users', 'icon icon-group', '#', '', NULL, 50, 1, 0, 0),
(45, 'Users', 'icon icon-user', 'user/user', 'index', NULL, 1, 1, 44, 1),
(46, 'Groups', 'icon icon-list', 'user/groups', 'index', NULL, 2, 1, 44, 0),
(47, 'CMS', 'icon icon-align-justify', '#', '', NULL, 2, 1, 0, 0),
(58, 'Change Password', 'icon icon-key', 'auth', 'change_password', NULL, 51, 0, 0, 1),
(59, 'Logout', 'icon icon-off', 'auth/logout', 'index', NULL, 52, 0, 0, 1),
(65, 'Target Site', 'glyphicon glyphicon-globe', 'cms/target_screen', 'index', NULL, 1, 0, 0, 1),
(66, 'ScreenShot', 'glyphicon glyphicon-film', 'cms/screenshot', '', NULL, 3, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `screen_shots`
--

CREATE TABLE IF NOT EXISTS `screen_shots` (
`id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timing` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=147 ;

--
-- Dumping data for table `screen_shots`
--

INSERT INTO `screen_shots` (`id`, `site_id`, `url`, `image`, `timing`) VALUES
(141, 75, 'http://www.twitch.tv/castro_1021', 'img_MTQxODE1MDcwMQ.jpg', '2014-12-09 18:46:19'),
(140, 77, 'https://soundcloud.com/stream', 'img_MTQxODE1MDQ3NQ.jpg', '2014-12-09 18:42:21'),
(139, 76, 'http://opower.com/careers', 'img_MTQxODE1MDQwMQ.jpg', '2014-12-09 18:41:15'),
(138, 74, 'http://www.twitch.tv/castro_1021', 'img_MTQxODE0ODAwMQ.jpg', '2014-12-09 18:01:20'),
(137, 73, 'http://www.twitch.tv/', 'img_MTQxODE0NzcwMQ.jpg', '2014-12-09 17:56:22'),
(136, 72, 'http://www.twitch.tv/machinima', 'img_MTQxODE0NzQwMg.jpg', '2014-12-09 17:51:21'),
(135, 72, 'http://www.twitch.tv/machinima', 'img_MTQxODE0NzQwMQ.jpg', '2014-12-09 17:51:21'),
(134, 71, 'http://www.twitch.tv/', 'img_MTQxODE0NzE4MQ.jpg', '2014-12-09 17:47:41'),
(133, 69, 'http://www.twitch.tv/noxious_hs', 'img_MTQxODE0NzEwMQ.jpg', '2014-12-09 17:46:21'),
(132, 61, 'http://www.twitch.tv/esltv_sc2', 'img_MTQxODE0NTYwMQ.jpg', '2014-12-09 17:21:22'),
(130, 67, 'http://www.twitch.tv/reynad27', 'img_MTQxODA5NTIwMQ.jpg', '2014-12-09 03:21:20'),
(129, 65, 'https://soundcloud.com/stream', 'img_MTQxODA4ODYwMQ.jpg', '2014-12-09 01:31:09'),
(128, 66, 'http://www.twitch.tv/machinima', 'img_MTQxODA4MTEwMQ.jpg', '2014-12-08 23:26:19'),
(127, 58, 'http://www.twitch.tv/chrismd10', 'img_MTQxODA3MTUwMQ.jpg', '2014-12-08 20:46:17'),
(126, 61, 'http://www.twitch.tv/esltv_sc2', 'img_MTQxODA1OTI3Ng.jpg', '2014-12-08 17:23:31'),
(125, 60, 'http://www.twitch.tv/liquidsavjz', 'img_MTQxODA1OTIwMQ.jpg', '2014-12-08 17:21:16'),
(124, 60, 'http://www.twitch.tv/liquidsavjz', 'img_MTQxODA1ODMwMQ.jpg', '2014-12-08 17:06:14'),
(123, 65, 'https://soundcloud.com/stream', 'img_MTQxODAwMjIwMQ.jpg', '2014-12-08 01:31:07'),
(122, 64, 'https://soundcloud.com/stream', 'img_MTQxNzk4NjYwMQ.jpg', '2014-12-07 21:11:08'),
(121, 60, 'http://www.twitch.tv/towelliee', 'img_MTQxNzk4NTg0Mg.jpg', '2014-12-07 20:58:32'),
(120, 61, 'http://www.twitch.tv/esltv_sc2', 'img_MTQxNzk4NTc3Mw.jpg', '2014-12-07 20:57:22'),
(119, 63, 'http://www.twitch.tv/reynad27', 'img_MTQxNzk4NTcwMQ.jpg', '2014-12-07 20:56:13'),
(118, 60, 'http://www.twitch.tv/towelliee', 'img_MTQxNzk4NTQwMQ.jpg', '2014-12-07 20:51:10'),
(117, 51, 'http://www.twitch.tv/liquidsavjz', 'img_MTQxNzk3NDYwMQ.jpg', '2014-12-07 17:51:12'),
(116, 46, 'http://www.twitch.tv/liquidsavjz', 'img_MTQxNzk3MTY3NA.jpg', '2014-12-07 17:02:25'),
(115, 47, 'http://www.twitch.tv/swiftor', 'img_MTQxNzk3MTYwMQ.jpg', '2014-12-07 17:01:14'),
(114, 54, 'http://www.twitch.tv', 'img_MTQxNzk2ODAwMQ.jpg', '2014-12-07 16:01:13'),
(113, 46, 'http://www.twitch.tv/liquidsavjz', 'img_MTQxNzk2NzU0Ng.jpg', '2014-12-07 15:53:38'),
(112, 51, 'http://www.twitch.tv/liquidsavjz', 'img_MTQxNzk2NzQ3Mw.jpg', '2014-12-07 15:52:26'),
(111, 54, 'http://www.twitch.tv', 'img_MTQxNzk2NzQwMQ.jpg', '2014-12-07 15:51:13'),
(110, 49, 'http://www.sajidshah.com', 'img_MTQxNzk2Njk0OQ.jpg', '2014-12-07 15:43:35'),
(109, 47, 'http://www.twitch.tv/swiftor', 'img_MTQxNzk2Njg3Mw.jpg', '2014-12-07 15:42:29'),
(108, 54, 'http://www.twitch.tv', 'img_MTQxNzk2NjgwMQ.jpg', '2014-12-07 15:41:13'),
(131, 54, 'http://www.twitch.tv', 'img_MTQxODE0MDgwMQ.jpg', '2014-12-09 16:01:14'),
(142, 76, 'http://opower.com/careers', 'img_MTQxODE1MTMwMQ.jpg', '2014-12-09 18:56:13'),
(143, 75, 'http://www.twitch.tv/castro_1021', 'img_MTQxODE1MTYwMQ.jpg', '2014-12-09 19:01:23'),
(144, 71, 'http://www.twitch.tv/', 'img_MTQxODE1NzAwMQ.jpg', '2014-12-09 20:31:22'),
(145, 78, 'http://www.twitch.tv/snutzy', 'img_MTQxODE2MDkwMQ.jpg', '2014-12-09 21:36:22'),
(146, 79, 'http://www.twitch.tv/snutzy', 'img_MTQxODE2MTIwMQ.jpg', '2014-12-09 21:41:22');

-- --------------------------------------------------------

--
-- Table structure for table `target_screen`
--

CREATE TABLE IF NOT EXISTS `target_screen` (
`id` int(11) NOT NULL,
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `width` int(11) NOT NULL DEFAULT '0',
  `height` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=82 ;

--
-- Dumping data for table `target_screen`
--

INSERT INTO `target_screen` (`id`, `title`, `url`, `width`, `height`) VALUES
(61, 'http://www.twitch.tv/esltv_sc2', 'http://www.twitch.tv/esltv_sc2', 0, 2300),
(51, 'http://www.twitch.tv/liquidsavjz', 'http://www.twitch.tv/liquidsavjz', 0, 0),
(78, 'http://www.twitch.tv/snutzy', 'http://www.twitch.tv/snutzy', 0, 2500),
(55, 'testing', 'testing.net', 0, 0),
(56, 'http://www.twitch.tv/liquidsavjz', 'http://www.twitch.tv/', 0, 0),
(58, 'http://www.twitch.tv/chrismd10', 'http://www.twitch.tv/chrismd10', 0, 0),
(72, 'http://www.twitch.tv/machinima', 'http://www.twitch.tv/machinima', 0, 2000),
(75, 'http://www.twitch.tv/castro_1021', 'http://www.twitch.tv/castro_1021', 0, 3000),
(64, 'soundcloud test', 'https://soundcloud.com/stream', 0, 0),
(74, 'http://www.twitch.tv/castro_1021', 'http://www.twitch.tv/castro_1021', 0, 4000),
(81, 'ThxPhil Stream', 'www.twitch.tv/thxphil', 0, 0),
(79, 'Test3', 'http://www.twitch.tv/snutzy', 0, 2500),
(77, 'https://soundcloud.com/stream', 'https://soundcloud.com/stream', 0, 0),
(69, 'http://www.twitch.tv/noxious_hs', 'http://www.twitch.tv/noxious_hs', 0, 2000),
(71, 'http://www.twitch.tv/', 'http://www.twitch.tv/', 0, 2500);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`) VALUES
(1, 'admin', '$2a$08$Iz9MvWmnsq0Ud6snFGEuTOSyeZa0MlmYFR6Fb2YguF/y6ATKFfJFy', 'demo@deanstechno.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '182.185.116.72', '2014-12-09 22:39:20', '0000-00-00 00:00:00', '2014-12-10 06:39:20'),
(2, 'nahyan', '$2a$08$V6eDeRszVN7QiPDmUBR1/u8.VLKJc6OqQ2xPtAgwUwsfg/tcxf8d6', 'nahyan@deanstechno.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '192.168.0.104', '2013-05-13 06:45:26', '2013-05-08 07:14:01', '2013-05-13 14:45:26'),
(3, 'dawood', '$2a$08$UcxoY4J8EzsXlPaBPEazXeQYZZniy.Gqwlh/rgEQ9CVl6HD/w8hUC', 'dawood@deanstechno.com', 1, 0, NULL, NULL, NULL, NULL, NULL, '192.168.0.192', '2014-03-21 15:16:03', '2014-03-21 15:11:32', '2014-11-15 22:48:09'),
(4, 'Mali', '$P$B.rMBxet4wb5OE3wiKH6BjCkWBeJra/', 'ali@ithinq.net', 1, 0, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', '2014-10-24 16:55:36', '2014-10-24 16:55:24', '2014-10-24 21:55:36');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE IF NOT EXISTS `users_groups` (
`id` mediumint(8) unsigned NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 3),
(3, 3, 3),
(4, 4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_autologin`
--

CREATE TABLE IF NOT EXISTS `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_autologin`
--

INSERT INTO `user_autologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES
('c09dc2bdf4c72318cb23250e87316eff', 1, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36', '38.99.10.97', '2014-12-09 21:48:35'),
('d09f54820bee5ce4c7b955e1ceb17727', 1, 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31', '192.168.0.113', '2013-05-17 19:58:12'),
('dbb46f2812259d0777e08979b7767b92', 1, 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.110 Safari/537.36', '192.168.0.106', '2013-06-20 17:29:13'),
('e1eef7c570937686b57574ea7e6ec586', 1, 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0', '5.152.221.68', '2014-11-19 11:50:42');

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE IF NOT EXISTS `user_profiles` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`id`, `user_id`, `country`, `website`) VALUES
(1, 1, 'Pakistan', 'http://www.deanstechno.com'),
(2, 2, NULL, NULL),
(3, 4, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alarm`
--
ALTER TABLE `alarm`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `calendar`
--
ALTER TABLE `calendar`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_query`
--
ALTER TABLE `ci_query`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
 ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privileges`
--
ALTER TABLE `privileges`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `screen_shots`
--
ALTER TABLE `screen_shots`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `target_screen`
--
ALTER TABLE `target_screen`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_autologin`
--
ALTER TABLE `user_autologin`
 ADD PRIMARY KEY (`key_id`,`user_id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alarm`
--
ALTER TABLE `alarm`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=246;
--
-- AUTO_INCREMENT for table `calendar`
--
ALTER TABLE `calendar`
MODIFY `id` int(16) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `ci_query`
--
ALTER TABLE `ci_query`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `privileges`
--
ALTER TABLE `privileges`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `screen_shots`
--
ALTER TABLE `screen_shots`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=147;
--
-- AUTO_INCREMENT for table `target_screen`
--
ALTER TABLE `target_screen`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=82;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
